def minimum(a):
	opt=1
	while opt==1:
		x=int(input("Enter an element : "))
		a.append(x)
		
